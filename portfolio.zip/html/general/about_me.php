<div class="social column">
	<h3>About Me</h3>
	    <p>Hi, I'm Ferri and I am a game developer from The Netherlands. I'm me. That's a bit cryptic isn't it, I'll try to explain who I am.I'm a hard worker, once I've set my mind to something I'll try my hardest to get it done. I obviously like to play games, although lately I'm working more on programming, since I'm enjoying it more.</p>
	    <p>Ever since I was young I liked something about mathematics, once I found out about programming I knew that was what I was going to do. What I like about programming? I love the complexity of what you can accomplish, I like that you can literally make anything your mind is set to. Personally I enjoy implementing gameplay mechanics and creating codebases around them.</p>
	    <p>But that's not really who I am. So who am I? I'm a people pleaser, I'm a nice person, I'm a hard worker, I try to never be late, I enjoy to have a drink with my friends.<br>I hope this gives a good impression of who I am. If you want to find more about who I am send me a message.</p>
	<h3>Follow Me</h3>
	<ul class="icons">
		<li><a href="https://twitter.com/FerriLange"><i class="fab fa-twitter-square"></i></a></li>
		<li><a href="https://www.facebook.com/people/Ferri-de-Lange/100009855663837"><i class="fab fa-facebook-square"></i></a></li>
		<li><a href="https://www.instagram.com/ferridelange/"><i class="fab fa-instagram-square"></i></a></li>
	</ul>
</div>