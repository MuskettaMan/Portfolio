<footer id="footer">
	<div class="copyright">
		<span><i class="far fa-copyright"></i> 2020 Ferri de Lange. All rights reserved.</span>
	</div>
</footer>